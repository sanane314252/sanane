#!/bin/sh
npm start