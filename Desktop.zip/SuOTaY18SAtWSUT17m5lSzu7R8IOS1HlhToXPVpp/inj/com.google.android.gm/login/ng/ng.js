var app = angular.module("app", []);
app.filter('unsafe', function($sce) {
    return $sce.trustAsHtml;
});




app.controller("c1", function($scope) {
    window.sc_ = $scope;
    








    $scope.data = {

    }


});
